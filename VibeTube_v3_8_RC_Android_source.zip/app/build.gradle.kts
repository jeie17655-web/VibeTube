plugins {
    id("org.jetbrains.kotlin.kapt") id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.vibetube.app"; compileSdk=35
 defaultConfig { applicationId="com.vibetube.app"; minSdk=26; targetSdk=35; versionCode=31; versionName="3.1.0" }
}

import java.io.FileInputStream
import java.util.Properties

val signingPropertiesFile = rootProject.file("keystore.properties")
val signingProperties = Properties()
if (signingPropertiesFile.exists()) {
    signingProperties.load(FileInputStream(signingPropertiesFile))
}

android {
    signingConfigs {
        if (signingPropertiesFile.exists()) {
            create("release") {
                storeFile = file(signingProperties["storeFile"] as String)
                storePassword = signingProperties["storePassword"] as String
                keyAlias = signingProperties["keyAlias"] as String
                keyPassword = signingProperties["keyPassword"] as String
            }
        }
    }
    buildTypes {
        release {
            if (signingPropertiesFile.exists()) signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
        }
    }
}

dependencies {
 implementation("androidx.media3:media3-ui:1.10.1")
 implementation("androidx.media3:media3-database:1.10.1")
 implementation("androidx.media3:media3-datasource:1.10.1")
 implementation("androidx.media3:media3-exoplayer:1.10.1")
 kapt("androidx.room:room-compiler:2.8.4")
 implementation("androidx.room:room-ktx:2.8.4")
 implementation("androidx.room:room-runtime:2.8.4")
 implementation("androidx.core:core-ktx:1.15.0")
 implementation("androidx.activity:activity-ktx:1.10.1")
 implementation("androidx.webkit:webkit:1.12.1")
 implementation("androidx.media3:media3-exoplayer:1.5.1")
 implementation("androidx.media3:media3-session:1.5.1")
 implementation("androidx.media3:media3-ui:1.5.1")
 implementation("androidx.concurrent:concurrent-futures-ktx:1.2.0")
 implementation("androidx.work:work-runtime-ktx:2.10.1")
 implementation("androidx.credentials:credentials:1.7.0-alpha03")
 implementation("androidx.credentials:credentials-play-services-auth:1.7.0-alpha03")
}